const out=document.querySelector('#dbg-out'),logEl=document.querySelector('#dbg-log');const esc=x=>String(x??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;');function log(msg){logEl.textContent+=(logEl.textContent==='Připraveno.'?'':'
')+msg}function chip(t,m){return `<div class="result-chip"><strong>${esc(t)}</strong><br><small>${esc(m)}</small></div>`}async function j(url,opt){log('FETCH '+url);const r=await fetch(url,opt);let d={};try{d=await r.json()}catch(e){d={error:'Neplatný JSON'}}log(url+' -> '+r.status);return {ok:r.ok,status:r.status,data:d}}document.querySelector('#dbg-routes').onclick=async()=>{let x=await j('/api/v1/debug/routes');out.innerHTML=x.ok?chip('Routy',`${(x.data.routes||[]).length} záznamů`)+`<pre class="hex-box">${esc((x.data.routes||[]).join('
'))}</pre>`:chip('Chyba',x.data.error||x.status)};document.querySelector('#dbg-ping').onclick=async()=>{let x=await j('/api/v1/debug/ping',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({hello:'world'})});out.innerHTML=x.ok?chip('Ping OK',JSON.stringify(x.data)):chip('Ping chyba',x.data.error||x.status)};document.querySelector('#dbg-run').onclick=async()=>{out.innerHTML='';logEl.textContent='Připraveno.';const tests=[['Health','/health'],['Auth me','/api/v1/auth/me'],['Routes','/api/v1/debug/routes'],['Status','/api/v1/system-status'],['Inventory','/api/v1/inventory/sessions'],['Locations','/api/v1/locations']];let html='';for(const [name,url] of tests){let r=await j(url);html+=chip(name,`HTTP ${r.status} · ${r.ok?'OK':'FAIL'}${r.data.error?' · '+r.data.error:''}`)}out.innerHTML=html}
document.querySelector('#dbg-env').onclick=async()=>{
    let x=await j('/api/v1/debug/env');
    if(!x.ok){
        out.innerHTML=chip('Chyba kontroly', x.data.error || x.status);
        return;
    }
    const d = x.data;
    let html = chip('Systém', `Python: ${d.python} · Flask: ${d.flask}`);
    html += chip('Zápis do /data', d.data_write === 'OK' ? 'OK (máme práva zápisu)' : `CHYBA: ${d.data_write}`);

    const deps = Object.entries(d.deps||{}).map(([k,v]) => `${k}: ${v}`).join(' · ');
    html += chip('Knihovny', deps);

    const files = Object.entries(d.files||{}).map(([k,v]) => `${k}: ${v}`).join('<br>');
    html += chip('Verze souborů (datum změny)', files);

    out.innerHTML = html;
};
