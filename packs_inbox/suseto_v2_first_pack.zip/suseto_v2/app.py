from flask import Flask, jsonify, render_template, request
from services.decision_engine import analyze_payload

app = Flask(__name__, template_folder='templates', static_folder='static')
application = app

@app.route('/')
def home():
    return render_template('pages/rozcestnik.html')

@app.route('/navigator')
def navigator():
    return render_template('pages/navigator.html')

@app.route('/health')
def health():
    return jsonify({"status": "ok", "app": "suseto_v2"})

@app.route('/api/v1/analyze', methods=['POST'])
def api_analyze():
    data = request.get_json(silent=True) or {}
    payload = data.get('payload')
    if payload is None:
        payload = request.form.get('payload', '')
    return jsonify(analyze_payload(payload or ''))

if __name__ == '__main__':
    app.run(debug=True)
