from flask import Flask, jsonify, render_template, request
from services.decision_engine import analyze_payload
from services.generator_engine import profile_bundle
from services.state_machine import build_state_graph, replay_path, get_state_detail
from services.heuristic_engine import build_frontier
from services.auth_lab import simulate
from services.run_store import save_run, list_runs, get_run
from services.aidc_service import generate_qr, generate_barcode, scan_analysis
from services.aidc_batch import preview_csv, generate_batch
from services.registry_store import profiles, items, add_profile, add_item, set_status, match, export_csv_text, import_csv_text
from services.transform_service import analyze as transform_analyze, time_formats
app=Flask(__name__,template_folder="templates",static_folder="static"); app.config["TEMPLATES_AUTO_RELOAD"]=True; application=app
@app.route("/")
def home(): return render_template("pages/rozcestnik.html")
@app.route("/navigator")
def navigator(): return render_template("pages/navigator.html")
@app.route("/generator")
def generator(): return render_template("pages/generator.html")
@app.route("/legacy-lab")
def legacy_lab(): return render_template("pages/legacy_lab.html")
@app.route("/state-lab")
def state_lab(): return render_template("pages/state_lab.html")
@app.route("/aidc-studio")
def aidc_studio(): return render_template("pages/aidc_studio.html")
@app.route("/transform-lab")
def transform_lab(): return render_template("pages/transform_lab.html")
@app.route("/dashboard")
def dashboard(): return render_template("pages/dashboard.html")
@app.route("/registry")
def registry(): return render_template("pages/registry.html")
@app.route("/label-profiles")
def label_profiles(): return render_template("pages/label_profiles.html")
@app.route("/aidc-batch")
def aidc_batch(): return render_template("pages/aidc_batch.html")
@app.route("/scanner-lab")
def scanner_lab(): return render_template("pages/scanner_lab.html")
@app.route("/auth-lab")
def auth_lab(): return render_template("pages/auth_lab.html")
@app.route("/runs")
def runs(): return render_template("pages/runs.html")
@app.route("/health")
def health(): return jsonify({"status":"ok","modules":["navigator","generator","state_lab","auth_lab","run_history","aidc_studio","aidc_batch","registry","label_profiles","scanner_lab","transform_lab","dashboard"],"mode":"sandbox-only"})
def body(): return request.get_json(silent=True) or {}
@app.get("/api/v1/dashboard")
def dashboard_data():
 all_items=items(); states={x:sum(1 for i in all_items if i["status"]==x) for x in ("active","reserved","retired")}; return jsonify({"total":len(all_items),"states":states,"profiles":len(profiles()),"recent":sorted(all_items,key=lambda x:x.get("updated_at",""),reverse=True)[:8]})
@app.post("/api/v1/transform/analyze")
def transform_api():
 d=body(); return jsonify(transform_analyze(d.get("payload",""),d.get("key","")))
@app.get("/api/v1/transform/time")
def transform_time(): return jsonify(time_formats())
@app.route("/label-print/<item_id>")
def label_print(item_id):
 found=next((x for x in items() if x["id"]==item_id),None)
 if not found:return "Not found",404
 return render_template("pages/label_print.html",item=found)
@app.get("/api/v1/registry/export")
def registry_export():
 return Response(export_csv_text(),mimetype="text/csv",headers={"Content-Disposition":"attachment; filename=suseto-registry.csv"})
@app.post("/api/v1/registry/import")
def registry_import():
 f=request.files.get("file")
 if not f:return jsonify({"error":"Nahraj CSV soubor."}),400
 try:return jsonify(import_csv_text(f.read()))
 except (ValueError,UnicodeDecodeError) as e:return jsonify({"error":str(e)}),400
@app.get("/api/v1/registry")
def registry_list(): return jsonify({"items":items(request.args.get("q",""),request.args.get("status","")),"profiles":profiles()})
@app.post("/api/v1/registry")
def registry_add():
 try:return jsonify(add_item(body())),201
 except ValueError as e:return jsonify({"error":str(e)}),400
@app.post("/api/v1/registry/<item_id>/status")
def registry_status(item_id):
 try:return jsonify(set_status(item_id,body().get("status")))
 except ValueError as e:return jsonify({"error":str(e)}),400
@app.get("/api/v1/registry/match")
def registry_match(): return jsonify({"item":match(request.args.get("payload",""))})
@app.get("/api/v1/label-profiles")
def profiles_list(): return jsonify({"profiles":profiles()})
@app.post("/api/v1/label-profiles")
def profiles_add():
 try:return jsonify(add_profile(body())),201
 except ValueError as e:return jsonify({"error":str(e)}),400
@app.post("/api/v1/aidc/batch-preview")
def aidc_batch_preview():
 result,status=preview_csv(request.files.get("file")); return jsonify(result),status
@app.post("/api/v1/aidc/batch-generate")
def aidc_batch_generate():
 return generate_batch(request.files.get("file"),request.form.get("column","0"),request.form.get("kind","qr"),request.form.get("format","png"))
@app.post("/api/v1/aidc/generate")
def aidc_generate():
 d=body(); kind=d.get("kind","qr"); fmt=d.get("format","png"); data=d.get("data","")
 return generate_qr(data,fmt) if kind=="qr" else generate_barcode(data,kind,fmt)
@app.post("/api/v1/aidc/analyze-scan")
def aidc_analyze_scan():
 d=body(); result=scan_analysis(d.get("payload","")); result["registry_match"]=match(result["payload"]); saved=save_run({"kind":"aidc_scan","input":{"payload_preview":result["payload"][:120]},"summary":{"classification":result["classification"],"length":result.get("length",0)}}); return jsonify({**result,"run":saved})
@app.post("/api/v1/analyze")
def api_analyze():
 d=body(); return jsonify(analyze_payload(d.get("payload") or request.form.get("payload", "")))
@app.post("/api/v1/generate-profile")
def api_generate_profile():
 d=body(); return jsonify(profile_bundle(d.get("seed") or "sample-seed"))
@app.post("/api/v1/state-graph")
def api_state_graph(): return jsonify(build_state_graph(body().get("seed") or "demo"))
@app.post("/api/v1/state-detail")
def api_state_detail(): return jsonify(get_state_detail(body().get("state_id","root")))
@app.post("/api/v1/replay")
def api_replay(): return jsonify(replay_path(body().get("path") or ["root","profile","filter","validate"]))
@app.post("/api/v1/heuristic-run")
def heuristic_run():
 d=body(); result=build_frontier(d.get("seed","demo"),d.get("strategy","best_first"),d.get("budget",8),d.get("weights")); saved=save_run({"kind":"heuristic","input":{"seed":d.get("seed","demo"),"strategy":result["strategy"],"budget":result["budget"],"weights":result["weights"]},"summary":{"top_score":result["frontier"][0]["score"] if result["frontier"] else 0,"count":len(result["frontier"])}}); return jsonify({**result,"run":saved})
@app.post("/api/v1/auth-simulate")
def auth_simulate():
 d=body(); result=simulate(d); saved=save_run({"kind":"auth_simulation","input":d,"summary":{"scenario":result["scenario"],"risk":result["risk"],"sandbox":True}}); return jsonify({**result,"run":saved})
@app.get("/api/v1/runs")
def api_runs(): return jsonify({"runs":list_runs()})
@app.get("/api/v1/runs/<run_id>")
def api_run(run_id):
 r=get_run(run_id); return (jsonify(r),200) if r else (jsonify({"error":"not_found"}),404)
