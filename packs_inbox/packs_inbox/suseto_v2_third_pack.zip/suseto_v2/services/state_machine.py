def build_state_graph(seed):
 nodes=[{'id':'root','label':'INIT','score':1.0,'state':'init'},{'id':'profile','parent':'root','label':'PROFILE_INPUT','score':0.94,'state':'profile'},{'id':'expand','parent':'profile','label':'GENERATE_CANDIDATES','score':0.92,'state':'expand'},{'id':'filter','parent':'expand','label':'HEURISTIC_FILTER','score':0.89,'state':'filter'},{'id':'validate','parent':'filter','label':'VALIDATE_RESULT','score':0.95,'state':'validate'}]
 return {'seed':seed,'nodes':nodes,'edges':[{'from':'root','to':'profile'},{'from':'profile','to':'expand'},{'from':'expand','to':'filter'},{'from':'filter','to':'validate'}]}
def replay_path(path): return {'path':path,'events':[{'step':i,'state':s,'reason':'auto-transition'} for i,s in enumerate(path,1)]}
def get_state_detail(state_id): return {'state_id':state_id,'notes':'detail placeholder','heuristics':['length','entropy','prefix','wrapper'],'next':['expand','backtrack']}
