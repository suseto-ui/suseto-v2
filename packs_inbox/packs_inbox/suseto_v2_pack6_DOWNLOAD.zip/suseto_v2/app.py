from flask import Flask, jsonify, render_template, request
from services.decision_engine import analyze_payload
from services.generator_engine import profile_bundle
from services.state_machine import build_state_graph, replay_path, get_state_detail
from services.heuristic_engine import build_frontier
from services.auth_lab import simulate
from services.run_store import save_run, list_runs, get_run
app=Flask(__name__,template_folder="templates",static_folder="static"); app.config["TEMPLATES_AUTO_RELOAD"]=True; application=app
@app.route("/")
def home(): return render_template("pages/rozcestnik.html")
@app.route("/navigator")
def navigator(): return render_template("pages/navigator.html")
@app.route("/generator")
def generator(): return render_template("pages/generator.html")
@app.route("/legacy-lab")
def legacy_lab(): return render_template("pages/legacy_lab.html")
@app.route("/state-lab")
def state_lab(): return render_template("pages/state_lab.html")
@app.route("/auth-lab")
def auth_lab(): return render_template("pages/auth_lab.html")
@app.route("/runs")
def runs(): return render_template("pages/runs.html")
@app.route("/health")
def health(): return jsonify({"status":"ok","modules":["navigator","generator","state_lab","auth_lab","run_history"],"mode":"sandbox-only"})
def body(): return request.get_json(silent=True) or {}
@app.post("/api/v1/analyze")
def api_analyze():
 d=body(); return jsonify(analyze_payload(d.get("payload") or request.form.get("payload", "")))
@app.post("/api/v1/generate-profile")
def api_generate_profile():
 d=body(); return jsonify(profile_bundle(d.get("seed") or "sample-seed"))
@app.post("/api/v1/state-graph")
def api_state_graph(): return jsonify(build_state_graph(body().get("seed") or "demo"))
@app.post("/api/v1/state-detail")
def api_state_detail(): return jsonify(get_state_detail(body().get("state_id","root")))
@app.post("/api/v1/replay")
def api_replay(): return jsonify(replay_path(body().get("path") or ["root","profile","filter","validate"]))
@app.post("/api/v1/heuristic-run")
def heuristic_run():
 d=body(); result=build_frontier(d.get("seed","demo"),d.get("strategy","best_first"),d.get("budget",8),d.get("weights")); saved=save_run({"kind":"heuristic","input":{"seed":d.get("seed","demo"),"strategy":result["strategy"],"budget":result["budget"],"weights":result["weights"]},"summary":{"top_score":result["frontier"][0]["score"] if result["frontier"] else 0,"count":len(result["frontier"])}}); return jsonify({**result,"run":saved})
@app.post("/api/v1/auth-simulate")
def auth_simulate():
 d=body(); result=simulate(d); saved=save_run({"kind":"auth_simulation","input":d,"summary":{"scenario":result["scenario"],"risk":result["risk"],"sandbox":True}}); return jsonify({**result,"run":saved})
@app.get("/api/v1/runs")
def api_runs(): return jsonify({"runs":list_runs()})
@app.get("/api/v1/runs/<run_id>")
def api_run(run_id):
 r=get_run(run_id); return (jsonify(r),200) if r else (jsonify({"error":"not_found"}),404)
