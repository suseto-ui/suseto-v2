from flask import Flask, jsonify, render_template, request
from services.decision_engine import analyze_payload
from services.generator_engine import profile_bundle

app = Flask(__name__, template_folder='templates', static_folder='static')
application = app

@app.route('/')
def home():
    return render_template('pages/rozcestnik.html')

@app.route('/navigator')
def navigator():
    return render_template('pages/navigator.html')

@app.route('/generator')
def generator():
    return render_template('pages/generator.html')

@app.route('/legacy-lab')
def legacy_lab():
    return render_template('pages/legacy_lab.html')

@app.route('/health')
def health():
    return jsonify({'status': 'ok', 'app': 'suseto_v2', 'modules': ['navigator', 'generator', 'legacy_lab']})

@app.route('/api/v1/analyze', methods=['POST'])
def api_analyze():
    data = request.get_json(silent=True) or {}
    payload = data.get('payload')
    if payload is None:
        payload = request.form.get('payload', '')
    return jsonify(analyze_payload(payload or ''))

@app.route('/api/v1/generate-profile', methods=['POST'])
def api_generate_profile():
    data = request.get_json(silent=True) or {}
    seed = data.get('seed') or request.form.get('seed', 'sample-seed')
    return jsonify(profile_bundle(seed))

if __name__ == '__main__':
    app.run(debug=True)
