import base64
import json
import re
from datetime import datetime, timezone

def _ascii_ratio(text: str) -> float:
    if not text:
        return 0.0
    ok = sum(1 for ch in text if 32 <= ord(ch) <= 126 or ch in "\r\n\t")
    return round(ok / len(text), 3)

def _looks_like_jwt(value: str) -> bool:
    parts = value.split('.')
    return len(parts) == 3 and all(parts)

def _looks_like_hex(value: str) -> bool:
    compact = value.replace(' ', '').replace(':', '')
    return len(compact) >= 8 and len(compact) % 2 == 0 and re.fullmatch(r'[0-9A-Fa-f]+', compact) is not None

def _looks_like_b64(value: str) -> bool:
    return len(value) >= 8 and len(value) % 4 == 0 and re.fullmatch(r'[A-Za-z0-9+/=]+', value) is not None

def _looks_like_ts(value: str) -> bool:
    return value.isdigit() and len(value) in (10, 13)

def _decode_b64(value: str):
    try:
        raw = base64.b64decode(value, validate=True)
        return {"ok": True, "preview": raw.decode('utf-8', errors='replace')[:220]}
    except Exception:
        return {"ok": False}

def _decode_hex(value: str):
    try:
        raw = bytes.fromhex(value.replace(' ', '').replace(':', ''))
        return {"ok": True, "preview": raw.decode('utf-8', errors='replace')[:220]}
    except Exception:
        return {"ok": False}

def _decode_jwt(value: str):
    try:
        h, p, s = value.split('.')
        pad = lambda v: v + '=' * (-len(v) % 4)
        header = json.loads(base64.urlsafe_b64decode(pad(h)).decode())
        payload = json.loads(base64.urlsafe_b64decode(pad(p)).decode())
        return {"ok": True, "header": header, "payload": payload, "sig_len": len(s)}
    except Exception:
        return {"ok": False}

def _decode_ts(value: str):
    try:
        dt = datetime.fromtimestamp(int(value) / 1000, tz=timezone.utc) if len(value) == 13 else datetime.fromtimestamp(int(value), tz=timezone.utc)
        return {"ok": True, "preview": dt.isoformat()}
    except Exception:
        return {"ok": False}

def analyze_payload(payload: str):
    payload = (payload or '').strip()
    out = {
        "input": payload,
        "meta": {"length": len(payload), "ascii_ratio": _ascii_ratio(payload), "empty": payload == ''},
        "classifications": [],
        "tree": [],
        "recommendations": [],
    }
    if not payload:
        out["recommendations"].append("Vlož payload pro zahájení analýzy.")
        return out
    out["tree"].append({"id": "root", "label": "Input payload", "value": payload[:160], "score": 1.0, "kind": "source"})
    for prefix, label, score in [("WIFI:", "wifi_payload", 0.99), ("HOTP:", "hotp_payload", 0.97), ("GPS:", "gps_epoch_payload", 0.95), ("FAT:", "fat_datetime_payload", 0.95), ("XOR:", "xor_wrapped_payload", 0.98), ("B85:", "base85_wrapped_payload", 0.98)]:
        if payload.startswith(prefix):
            out["classifications"].append({"type": label, "confidence": score})
    if _looks_like_jwt(payload):
        out["classifications"].append({"type": "jwt_candidate", "confidence": 0.96})
        dec = _decode_jwt(payload)
        if dec["ok"]:
            out["tree"].append({"id": "jwt", "parent": "root", "label": "JWT decoded", "value": json.dumps(dec["payload"], ensure_ascii=False)[:180], "score": 0.96, "kind": "transform"})
    if _looks_like_hex(payload):
        out["classifications"].append({"type": "hex_candidate", "confidence": 0.82})
        dec = _decode_hex(payload)
        if dec["ok"]:
            out["tree"].append({"id": "hex", "parent": "root", "label": "Hex decoded", "value": dec["preview"], "score": 0.84, "kind": "transform"})
    if _looks_like_b64(payload):
        out["classifications"].append({"type": "base64_candidate", "confidence": 0.80})
        dec = _decode_b64(payload)
        if dec["ok"]:
            out["tree"].append({"id": "b64", "parent": "root", "label": "Base64 decoded", "value": dec["preview"], "score": 0.83, "kind": "transform"})
    if _looks_like_ts(payload):
        out["classifications"].append({"type": "unix_timestamp_candidate", "confidence": 0.91})
        dec = _decode_ts(payload)
        if dec["ok"]:
            out["tree"].append({"id": "ts", "parent": "root", "label": "Unix timestamp interpreted", "value": dec["preview"], "score": 0.91, "kind": "transform"})
    if not out["classifications"]:
        out["classifications"].append({"type": "plain_text_or_unknown", "confidence": 0.55})
        out["recommendations"].append("Zkusit více vstupů a porovnat invariantní a proměnné části.")
    else:
        out["recommendations"].append("Porovnat payload s dalšími skeny a hledat stabilní segmenty.")
    out["classifications"] = sorted(out["classifications"], key=lambda x: x["confidence"], reverse=True)
    return out
