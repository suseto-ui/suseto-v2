import base64
import datetime
import hmac
import hashlib

SECRET_KEY = 'suseto-v2-dev'

def unix_ts():
    return str(int(datetime.datetime.now().timestamp()))

def unix_ts_ms():
    return str(int(datetime.datetime.now().timestamp() * 1000))

def wifi_payload(ssid: str, password: str, security: str = 'WPA'):
    return f"WIFI:S:{ssid};T:{security};P:{password};;"

def hotp_payload(counter: int = 1):
    sig = hmac.new(SECRET_KEY.encode(), str(counter).encode(), hashlib.sha256).hexdigest()[:6].upper()
    return f"HOTP:{counter}:{sig}"

def base64_wrap(text: str):
    return base64.b64encode(text.encode()).decode()

def profile_bundle(seed: str):
    return {
        'seed': seed,
        'unix_ts': unix_ts(),
        'unix_ts_ms': unix_ts_ms(),
        'base64': base64_wrap(seed),
        'hotp_like': hotp_payload(1),
    }
