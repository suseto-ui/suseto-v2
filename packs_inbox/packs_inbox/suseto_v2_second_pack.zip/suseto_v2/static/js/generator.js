const form = document.getElementById('generator-form');
const seedInput = document.getElementById('seed');
const output = document.getElementById('generator-output');
function chip(k,v){const d=document.createElement('div');d.className='result-chip';d.innerHTML=`<strong>${k}</strong><br><small>${v}</small>`;return d}
form?.addEventListener('submit', async (e)=>{e.preventDefault();output.innerHTML='<div class="result-chip">Generuji…</div>';const seed=seedInput.value.trim();const r=await fetch('/api/v1/generate-profile',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({seed})});const data=await r.json();output.innerHTML='';Object.entries(data).forEach(([k,v])=>output.appendChild(chip(k,v)))});
