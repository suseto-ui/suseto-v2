from flask import Flask, jsonify, render_template, request
from services.decision_engine import analyze_payload
from services.generator_engine import profile_bundle
from services.state_machine import build_state_graph, replay_path, get_state_detail

app = Flask(__name__, template_folder="templates", static_folder="static")
app.config["TEMPLATES_AUTO_RELOAD"] = True
application = app

@app.route("/")
def home():
    return render_template("pages/rozcestnik.html")

@app.route("/navigator")
def navigator():
    return render_template("pages/navigator.html")

@app.route("/generator")
def generator():
    return render_template("pages/generator.html")

@app.route("/legacy-lab")
def legacy_lab():
    return render_template("pages/legacy_lab.html")

@app.route("/state-lab")
def state_lab():
    return render_template("pages/state_lab.html")

@app.route("/health")
def health():
    return jsonify({"status": "ok", "modules": ["navigator", "generator", "legacy_lab", "state_lab"]})

@app.route("/api/v1/analyze", methods=["POST"])
def api_analyze():
    data = request.get_json(silent=True) or {}
    payload = data.get("payload") or request.form.get("payload", "")
    return jsonify(analyze_payload(payload))

@app.route("/api/v1/generate-profile", methods=["POST"])
def api_generate_profile():
    data = request.get_json(silent=True) or {}
    seed = data.get("seed") or request.form.get("seed", "sample-seed")
    return jsonify(profile_bundle(seed))

@app.route("/api/v1/state-graph", methods=["POST"])
def api_state_graph():
    data = request.get_json(silent=True) or {}
    seed = data.get("seed") or "demo"
    return jsonify(build_state_graph(seed))

@app.route("/api/v1/state-detail", methods=["POST"])
def api_state_detail():
    data = request.get_json(silent=True) or {}
    return jsonify(get_state_detail(data.get("state_id", "root")))

@app.route("/api/v1/replay", methods=["POST"])
def api_replay():
    data = request.get_json(silent=True) or {}
    path = data.get("path") or ["root", "profile", "filter", "validate"]
    return jsonify(replay_path(path))
