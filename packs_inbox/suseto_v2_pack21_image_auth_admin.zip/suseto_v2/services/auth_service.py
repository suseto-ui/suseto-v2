import json, hashlib, secrets
from datetime import datetime, timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent/'data'; FILE=ROOT/'users.json'
def _now(): return datetime.now(timezone.utc).isoformat()
def _ensure():
 ROOT.mkdir(exist_ok=True)
 if not FILE.exists():
  salt=secrets.token_hex(8)
  pwd='admin123'
  FILE.write_text(json.dumps({'users':[{'username':'admin','role':'admin','active':True,'created_at':_now(),'last_login':None,'salt':salt,'password_hash':hashlib.sha256((salt+pwd).encode()).hexdigest()}]},ensure_ascii=False,indent=2))
def _load(): _ensure(); return json.loads(FILE.read_text())
def _save(data): ROOT.mkdir(exist_ok=True); FILE.write_text(json.dumps(data,ensure_ascii=False,indent=2))
def list_users():
 data=_load();
 return [{'username':u['username'],'role':u['role'],'active':u.get('active',True),'created_at':u.get('created_at'),'last_login':u.get('last_login')} for u in data['users']]
def create_user(username,password,role='viewer'):
 data=_load(); username=str(username).strip(); role=role if role in {'admin','operator','viewer'} else 'viewer'
 if not username or not password: raise ValueError('Vyplň uživatele i heslo.')
 if any(u['username']==username for u in data['users']): raise ValueError('Uživatel už existuje.')
 salt=secrets.token_hex(8); data['users'].append({'username':username,'role':role,'active':True,'created_at':_now(),'last_login':None,'salt':salt,'password_hash':hashlib.sha256((salt+password).encode()).hexdigest()}); _save(data); return {'username':username,'role':role,'active':True}
def set_role(username,role):
 data=_load();
 for u in data['users']:
  if u['username']==username: u['role']=role; _save(data); return {'username':username,'role':role}
 raise ValueError('Uživatel nebyl nalezen.')
def toggle_active(username):
 data=_load();
 for u in data['users']:
  if u['username']==username: u['active']=not u.get('active',True); _save(data); return {'username':username,'active':u['active']}
 raise ValueError('Uživatel nebyl nalezen.')
def verify(username,password):
 data=_load()
 for u in data['users']:
  if u['username']==username and u.get('active',True):
   if hashlib.sha256((u['salt']+password).encode()).hexdigest()==u['password_hash']:
    u['last_login']=_now(); _save(data); return {'username':u['username'],'role':u['role']}
 return None
